import Index from './components/index/index'
import Login from './components/login/login'
import Footlist from './components/nav/footlist'
import Food from './components/sort/food'
// 发表评论
import Sendcom from './components/comment/sendcom'

// 设置路由
export default 
function(router){
router.addRoutes([
    {path:'/',redirect:{name:'index'}},
    // 首页
    {name:'index',path:'/index',component:Index},
    // 底部 文字介绍
    {name:'footlist',path:'/footlist',component:Footlist},
    // 登录 注册
    {name:'login',path:'/login',component:Login},
    // 食品分类 婴儿食品
    {name:'food',path:'/food',component:Food},
    // 发表评论
    {name:'sendcom',path:'/sendcom',component:Sendcom},
])
}
