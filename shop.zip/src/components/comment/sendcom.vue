<template>
<div class="bigbox">
    <div class="combox">
        <div class='logo_header'>
            <img src="../../assets/images/navlogo_1.jpg" alt="">
            <span class="welcome">欢迎来到澳新！</span>
        </div>
    </div>
</div>
</template>

<style scoped>
.bigbox {
    width: 100%;;
}
.combox {
    width: 1200px;
    margin:0 auto;
    border:1px solid red;
}
.welcome {
    font-size:14px;
    color:#999;
}
</style>

<style>

</style>


