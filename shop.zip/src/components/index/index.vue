<template>
  <div id="app">
    <!-- 顶部导航 -->
    <navheader></navheader>
    <!-- 商品系列导航 -->
    <navlist></navlist>
    <!-- 轮播 -->
    <carousel></carousel>
    <!-- 商品系列轮播 -->
    <div class="block">
        <div class="update center">
             <span class="update-left">每日上新</span>
             <span class="update-right">更新产品&nbsp;&nbsp;></span>
        </div>
        <div class="container">
            <div class="mhn-slide">
                <div class="mhn-item">
                    <div class="mhn-inner">
                    <img src="../../../static/index/block.png" alt="">
                    </div>
                <div class="mhn-text">
                    <p>资生堂新透白美肌 臻白祛斑精粹水150ML</p>
                    <p>汇率：5.0704</p>
                    <p>
                        <span>$50</span>
                        <a href="javascript:;">立即购买</a>
                    </p>
                </div>
            </div>
            <div class="mhn-item">
                <div class="mhn-inner">
                    <img src="../../../static/index/block.png" alt="">
                </div>
                <div class="mhn-text">
                <p>资生堂新透白美肌 臻白祛斑精粹水150ML</p>
                <p>汇率：5.0704</p>
                <p>
                    <span>$50</span>
                    <a href="javascript:;">立即购买</a>
                </p>
                </div>
            </div>
            <div class="mhn-item">
                    <div class="mhn-inner">
                    <img src="../../../static/index/block.png" alt="">
                </div>
                <div class="mhn-text">
                <p>资生堂新透白美肌 臻白祛斑精粹水150ML</p>
                <p>汇率：5.0704</p>
                <p>
                    <span>$50</span>
                    <a href="javascript:;">立即购买</a>
                </p>
                </div>
            </div>
            <div class="mhn-item">
                    <div class="mhn-inner">
                    <img src="../../../static/index/block.png" alt="">
                </div>
                <div class="mhn-text">
                <p>资生堂新透白美肌 臻白祛斑精粹水150ML</p>
                <p>汇率：5.0704</p>
                <p>
                    <span>$50</span>
                    <a href="javascript:;">立即购买</a>
                </p>
                </div>
            </div>
        </div>
        <span class="arrow-left arrow"> < </span>
        <span class="arrow-right arrow"> > </span>
    </div>
    </div>

    <!-- 今日特价 -->
    <div class="vipbox">
        <div class="vipmain">
            <span class="vip">今日特价 </span>
            <div class="dayspecial">
                <div class="day-left">
                    <img src="../../assets/images/index/day.jpg" alt="">
                </div>
                <ul class="day-right">
                    <li>
                        <a href="#">
                            <div class="li_left">
                                <p>Swisse 美肌幼白亮白脸50粒</p>
                                <p>美肌幼白多效精华全身亮白脸部</p>
                                <p>
                                    <span>$50</span>
                                    <span>$50</span>
                                    <span>汇率：5.0704</span>
                                </p>
                                <p>立即购买</p>
                            </div>
                            <div class="li_right">
                                <img src="../../assets/images/index/day00.jpg" alt="">
                            </div>
                        </a>
                    </li>
                   <li>
                        <a href="#">
                            <div class="li_left">
                                <p>Swisse 美肌幼白亮白脸50粒</p>
                                <p>美肌幼白多效精华全身亮白脸部</p>
                                <p>
                                    <span>$50</span>
                                    <span>$50</span>
                                    <span>汇率：5.0704</span>
                                </p>
                                <p>立即购买</p>
                            </div>
                            <div class="li_right">
                                <img src="../../assets/images/index/day00.jpg" alt="">
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <div class="li_left">
                                <p>Swisse 美肌幼白亮白脸50粒</p>
                                <p>美肌幼白多效精华全身亮白脸部</p>
                                <p>
                                    <span>$50</span>
                                    <span>$50</span>
                                    <span>汇率：5.0704</span>
                                </p>
                                <p>立即购买</p>
                            </div>
                            <div class="li_right">
                                <img src="../../assets/images/index/day00.jpg" alt="">
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <div class="li_left">
                                <p>Swisse 美肌幼白亮白脸50粒</p>
                                <p>美肌幼白多效精华全身亮白脸部</p>
                                <p>
                                    <span>$50</span>
                                    <span>$50</span>
                                    <span>汇率：5.0704</span>
                                </p>
                                <p>立即购买</p>
                            </div>
                            <div class="li_right">
                                <img src="../../assets/images/index/day00.jpg" alt="">
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>


    <!-- 热门品牌 -->
    <div class="hotbrand">
        <!-- 热门品牌 头部 -->
        <div class="hothead"></div>
        <!-- 热门品牌 主体展示 -->
        <div class="hotbox">
            <!-- 主题展示 主体图片 -->
            <div class="hotmain">
                <a class="hot_1" href="https://www.baidu.com/">
                    <p class="imp"><span>Aptamil</span>品牌商</p>
                    <p class="hotcolor">35元起</p>
                    <img src="../../assets/images/index/hot.jpg" alt="">
                </a>
                <a class="hot_2"  href="https://www.baidu.com/">
                    <p class="imp"><span>Aptamil</span>品牌商</p>
                    <p class="hotcolor">35元起</p>
                    <img src="../../assets/images/index/hot.jpg" alt="">
                </a>
                <a class="hot_3"  href="https://www.baidu.com/">
                    <div class="hot_3_top">
                        <div class="hot_3_left">
                            <p class="imp"><span>Aptamil</span>品牌商</p>
                            <p class="hotcolor">35元起</p>
                        </div>
                        <img class="smallimg" src="../../assets/images/index/hot.jpg" alt="">
                    </div>
                    <div class="hot_3_foot">
                        <div class="hot_3_left">
                            <p class="imp"><span>Aptamil</span>品牌商</p>
                            <p class="hotcolor">35元起</p>
                        </div>
                        <img class="smallimg" src="../../assets/images/index/hot.jpg" alt="">
                    </div>
                </a>
            </div>
        </div>
    </div>

    <!-- 会员特权 -->
    <div class="vipbox">
        <div class="vipmain">
            <span class="vip">会员特权</span>
            <ul class="vipgoods">
                <li class="vipF">
                    <a href="javascript:;">
                        <div class="vip-left">
                            <p class="viplevel_1">会员等级</p>
                            <p class="vipdetail_1">查看详情</p>
                        </div>
                        <div class="vip-right">
                            <img src="../../assets/images/index/vip.png" alt="">
                        </div>
                    </a>
                </li>
                <li class="vipS">
                    <a href="javascript:;">
                        <div class="vip-left">
                            <p class="viplevel_2">会员等级</p>
                            <p class="vipdetail_2">查看详情</p>
                        </div>
                        <div class="vip-right">
                            <img src="../../assets/images/index/vip.png" alt="">
                        </div>
                    </a>
                </li>
                <li class="vipT">
                    <a href="javascript:;">
                        <div class="vip-left">
                            <p class="viplevel_3">会员等级</p>
                            <p class="vipdetail_3">查看详情</p>
                        </div>
                        <div class="vip-right">
                            <img src="../../assets/images/index/vip.png" alt="">
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <!-- 商品分类展示 -->
    <div class="goodsort">
        <!-- 版心 -->
        <div class="goodsbox">
            <!-- 健康食品 -->
            <div class="healthy">
               <healtitle></healtitle>
                <!-- 图片盒子 -->
                <div class="healimg-box">
                    <!-- 系列 -->
                    <ul class="healimg">
                        <li>
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- 营养保健 -->
            <div class="healthy">
                <span class="spanleft">|</span><span class="spanleft">营养保健</span>
                <div class="spanright">
                    <span>健康食品</span><span>/</span>
                    <span>营养保健</span><span>/</span>
                    <span>美妆护肤</span><span>/</span>
                    <span>生活护理</span>
                    <span>更多护理</span>
                </div>
                <!-- 图片盒子 -->
                <div class="healimg-box">
                    <!-- 系列 -->
                    <ul class="healimg">
                        <li>
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- 美妆护肤 -->
            <div class="healthy">
                <span class="spanleft">|</span><span class="spanleft">美妆护肤</span>
                <div class="spanright">
                    <span>健康食品</span><span>/</span>
                    <span>营养保健</span><span>/</span>
                    <span>美妆护肤</span><span>/</span>
                    <span>生活护理</span>
                    <span>更多护理</span>
                </div>
                <!-- 图片盒子 -->
                <div class="healimg-box">
                    <!-- 系列 -->
                    <ul class="healimg">
                        <li>
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
             <!-- 生活护理 -->
            <div class="healthy">
                <span class="spanleft">|</span><span class="spanleft">美妆护肤</span>
                <div class="spanright">
                    <span>健康食品</span><span>/</span>
                    <span>营养保健</span><span>/</span>
                    <span>美妆护肤</span><span>/</span>
                    <span>生活护理</span>
                    <span>更多护理</span>
                </div>
                <!-- 图片盒子 -->
                <div class="healimg-box">
                    <!-- 系列 -->
                    <ul class="healimg">
                        <li>
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                        <li class="healColor">
                            <a href="http://www.baidu.com">
                            <img src="../../assets/images/index/healthy.jpg" alt="">
                            <p>Swisse 美肌幼白亮白脸50粒</p>
                            <span class="huiyu">汇率5.0704</span>
                            <span class="money">$1245</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 关于我们 -->
    <div class="aboutOur">
        <div class="aboutMain">
            <span>|</span><span>关于我们</span>
            <p>伴随着人民币不断升值以及国内物价上涨等汇率因素，“海购”变得越来越有性价比了。目前多家海外转运公司的竞争也使得其海购服务越来越完善和方便。
                作者撰写了本文，主要用于帮助有外币信用卡的网友们使用转运公司进行海购。总的来说，海购是一种自给自足自用形式的自助海购物行为，不依赖于第三方，
                其主要流程为转运公司网站注册并获取海外地址->国外网站购物->转运公司海外地址收取货物并发货到国内->清关并快递到手中，因为国外商家诚信度高，
                风险较低而且比找第三方商家更便宜，事实上许多第三方商家也是通过转运公司进行操作的。以下是海购攻略教程，建议准备尝试海购的网友仔细阅读后再操作。
                大量也孕育而生，帮助你选择美国真便宜的货物。</p>
              <div class="pic">
                    <img src="../../assets/images/index/about1.jpg" alt="">
                    <img src="../../assets/images/index/about1.jpg" alt="">
                    <img src="../../assets/images/index/about1.jpg" alt="">
                    <img src="../../assets/images/index/about1.jpg" alt="">
              </div>
        </div>
    </div> 
    <!-- 底部二维码部分 -->
    <div class="contain">
        <div class="email">
            <input type="email" placeholder="邮件"><span>发送</span>
        </div>
    </div>
    <!-- 底部介绍 -->
    <footlist></footlist>

  </div>
</template>
<script>
    import aaa from '../../assets/js/aaa.js'
    import navheader from '../nav/navheader'
    import navlist from '../nav/navlist'
    import carousel from './homepage/carousel'
    import footlist from '../nav/footlist'
    //  index 分组件
    import healtitle from './homepage/healtitle'
    // import healtitle from './homepage/healfood'
    export default{
    name: 'index',
    components: {
        navheader,
        navlist,
        carousel,
        footlist,
        //  index 组件
        healtitle
    },
    data(){
            return{
                
            }
     }
    }
</script>

<style scoped>
    * {
        margin: 0;
        padding:0;
        box-sizing: border-box;
        list-style: none;
        text-decoration: none;
    }

    /* 商品系列轮播 start*/
        .block {
            width: 100%;
            margin-top:45px;
        }
        .update {
            width: 1200px;
            margin:0 auto;
            height:  26px;
            background-color: #d4282d;
            color: #fff;
            padding: 1px 10px;
        }
        .update-left {
            float:left;
        }
        .update-right {
            float:right;
        }
        .container {
            width:1407px;
            margin:0 auto;
            overflow:hidden;
            position:relative;
        }
        .mhn-slide {
            padding:0 103px;
            white-space:nowrap;
            overflow-x: auto;
            font-size:14px;
        }
        .mhn-inner {
                padding-top:25px;
            }
        .mhn-item {
            width:25%;
            padding:0 30px;
            box-sizing:border-box;
            float:left
        }
            .mhn-item  img {
                width:50%;
                margin-left:30px;
                vertical-align:middle;
            }
            .mhn-text p:first-child {
                margin-top:15px;
            }
        .mhn-text p:nth-child(2) {
            width:110px;
            padding-left:5px;
            margin-top:20px;
            box-sizing:border-box;
            border:1px solid #e88d90;
        }
        .mhn-text p:last-child span{
            color:#d4282d;
            position:relative;
            bottom:-10px;
        }
        .mhn-text p:last-child a {
            background-color:#d4282d;
            float:right;
            padding:5px;
            border-radius:5px;
            color:#fff;
    }
    /* 轮播箭头*/
     .arrow {
         position:absolute;
         top:50%;
         transform:translateY(-50%);
         width:50px;
         height:100px;
         font-size:50px;
         text-align:center;
         line-height:100px;
     }
    .arrow-left {
         left:0;
     }
     .arrow-right {
         right:0;
     }
    .arrow:hover {
        cursor:pointer;    
       }
    /* 商品系列轮播 end*/

    /* 今日特价 start */
        .dayspecial {
            margin-top:25px;
            overflow: hidden;
        }
        .day-left {
            float:left;
            width: 226px;
            height:418px;
        }
        .day-left img {
            width: 226px;
            height:418px;
        }
        .day-right {
            width: 970px;
            float:right; 
        }
        .day-right li {
            float:left;
            width:50%;
            border:1px solid #f2f2f2;
            box-sizing: border-box;
        }
        .day-right li a {
            color:#333;
        }
        .day-right li:nth-child(1) {
            border-left:none;
            border-top:none;
        }
        .day-right li:nth-child(2) {
            border-top:none;
            border-right:none;
        }
        .day-right li:nth-child(3) {
            border-left:none;
            border-bottom:none;
        }
        .day-right li:nth-child(4) {
            border-right:none;
            border-bottom:none;
        }
        .li_left {
            float:left;
            margin-left:55px;
        }
        .li_right {
            float:right;
            width: 82px;
            height:130px;
            margin-top:33px;
            margin-bottom:20px;
            margin-right: 86px;
        }
        .li_left p:first-child {
            font-size:18px;
            margin-top:20px;
            margin-bottom:18px;
        }
        .li_left p:nth-child(2) {
            margin-bottom: 23px;
        }
        .li_left p:nth-child(2) {
            font-size:14px;
        }
        .li_left p span:first-child {
            font-size: 18px;
            color: #d4282d;
        }
        .li_left p span:nth-child(2) {
            font-size:12px;
            text-decoration: line-through;
        }
        .li_left p span:nth-child(3) {
            font-size:12px;
            display:inline-block;
            text-align: center;
            color:#d4282d;
            border:1px solid #d4282d;
            width: 87px;
            height:22px;
            line-height:20px;
            margin-left:30px;
        }
        .li_left p:last-child{
            background-color: #d4282d;
            color:#fff;
            width: 100px;
            height: 37px;
            line-height: 37px;
            text-align: center;
            border-radius: 7px;
            margin-top:24px;
            margin-bottom:18px;
        }
    /* 今日特价 end */

    /* 热门品牌 start */
        .hotbox {
            width: 100%;
            background-color: #f4f0ea;
            margin-top: 20px; 
            padding-top:1px;
            padding-bottom:60px;
        }
        .hotmain {
            width: 1200px;
            margin: 0 auto;
            margin-top: 60px;
            font-size: 16px;
        }
        .hot_1, .hot_2,.hot_3 {
            display:inline-block;
            text-align: center;
            padding-bottom:32px; 
            box-sizing: border-box;
        }
        .hot_1, .hot_2{
            background-color: #fff;
            width: 350px; 
            padding-top:53px;
            vertical-align: top;
            padding-bottom: 30px;
        }
        .hot_2 {
            margin-left: 4px;
        }
        .hot_3 {
            width: 470px;
            margin-left: 5px;
        }
       /* 热门 第三块 */
        .hot_3_top,.hot_3_foot {
            width: 100%;
            height: 49%;
            background-color: #fff;
            box-sizing: border-box;
        }
        .hot_3_foot {
            margin-top: 10px;
        }
        .hotmain p>span {
            display: inline-block;
            padding-bottom:12px;
            border-bottom: 1px solid #333;
        }
        .imp {
            color:#5d5d5d;
        }
        .hotcolor{
            color: #da5659;
            margin-top:13px;
        }
        .hot_3_left {
            text-align: left;
            width: 170px;
            display:inline-block;
            float: left;
            padding-top: 53px;
            margin-left:30px;
        }
        .smallimg {
            width: 87px;
            height:120px;
            margin-top: 30px;
            margin-bottom: 25px;
        }
    /* 热门品牌  end */

    /* 特权服务 start */
        .vipmain {
            width: 1200px;
            margin:0 auto;
            box-sizing: border-box;
            padding-top: 65px;
        }
        .vip {
            display:inline-block;
            box-sizing: border-box;
            width: 100%;
            height: 26px;
            background-color: #d4282d;
            color: #fff;
            padding: 1px 10px;
        }
        .vipgoods {
            width: 100%;
            margin-top: 23px;
        }
        .vipgoods li {
            float:left;
            width: 388px;
            height: 200px;
            overflow: hidden;
        }
        .vipgoods li>a {
            display: inline-block;
            text-decoration: none;
        }
        .vipF {
            background:#f4f0ea;
        }
        .vipS {
            background: #f1e8d9;
            margin-left: 18px;
        }
        .vipT {
            background:#f1e0e0;
            margin-left: 18px;
        }
        .vip-left {
            float:left;
            margin-left:40px;
            margin-top:65px;
            margin-right: 55px;
        }
        .vip-right {
            width: 95px;
            height: 159px;
            float:right;
            margin-top:20px;
        }
        .vip-right img {
            width: 100%;
            height: 100%;
        }
         .vip-left p:first-child {
             font-size:28px;
         }
         .vip-left p:nth-child(2) {
             width: 98px;
             height: 30px;
             line-height: 30px;
             text-align: center;          
             font-size:14px;
             color: #fff;
             border-radius: 15px;
             margin-left: 7px;
             margin-top:15px;
         }
         /* 不同部分  颜色设置 */
         .viplevel_1 {
            color: #aca8a2;
         }
         .vipdetail_1 {
            background-color: #a6a29c;
         }
         .viplevel_2 {
            color: #8b6a59;
         }
        .vipdetail_2 {
            background-color: #8b6a59;
         }
        .viplevel_3 {
            color: #af7c7c;
         }
        .vipdetail_3 {
            background-color: #aa7373;
         }
    /* 特权服务  end */

    /* 商品分类展示 start */
        .goodsort {
            width: 100%;
            background-color: #f5f5f5;
            padding-top: 1px;
            padding-bottom: 60px;
            box-sizing: border-box;
        }
        .goodsbox {
            width: 1200px;
            margin:0 auto;
            height:100%;
            box-sizing: border-box;
        }
        /* 清楚浮动 */
        .healimg-box {
            overflow: hidden;
        }
        .healthy {
            margin-top:50px;
        }
        
        .healimg {
            float: left;
        }
        .spanleft {
      display:inline-block;
      font-size: 28px;
      height: 55px;
      line-height: 55px;
  }
  .spanright {
      display: inline;
      float:right;
  }
        .healimg li{
            width: 290px;
            height: 505px;
            box-sizing: border-box;
            float: left;
            padding-left: 10px;
            padding-right: 10px;
            background-color: #fff;
        }
        .healColor {
        margin-left: 12px;
        }
         .healimg li img {
            width: 98%;
            height: 360px;
       }
        .healimg li a>p {
            border-top: 1px solid #adadad;
            font-size: 18px;
            color:#333;
            height: 60px;
            padding-top: 32px;
            /* border: 1px solid red; */
        }
        .healimg li a {
            display: inline-block;
            text-decoration: none;
        }
        .healimg li a>span {
            font-size: 18px;
            height: 27px;
            line-height: 27px;
            display: inline-block;
            box-sizing: border-box;
            margin-top:20px;
        }
        .healimg a .huiyu {
            float:left;
            color: #d4282d;
        }
        .healimg a .money {
            float: right;
            background-color: #d4282d;
            color:#fff;
            padding-left: 12px;
            padding-right: 12px;
            border-radius: 20px;
        }
      
    /* 商品分类展示 end */

    /* 关于我们 start */
        .aboutOur {
            width:100%;
            height: 490px;
            padding-top:50px;
        }
        .aboutMain {
            width: 1200px;
            height:375px;
            margin:0 auto;
            padding-left:2px;
        }
        .aboutMain span {
            font-size: 28px;
        }
        .aboutMain span:first-child {
            color: #d4282d;
            margin-right: 18px;
        }
        .aboutMain span:second-child {
            color: #333;
        }
        .aboutMain p {
            height: 120px;
            line-height: 28px;
            margin-top:15px;
            font-size:14px;
            color:#8d8d8d;
        }
        .pic img {
            vertical-align:middle;
            margin-left:-2px;
        }
    /* 关于我们 end */
    /* 底部二维码部分 start*/
        .contain {
            width: 100%;
            height:600px;
            background: url('../../assets/images/bg_foot.jpg') no-repeat;
            background-size:cover;
            box-sizing: border-box;
            padding-top:1px;
        }
        .contain .email{
            position: relative;
            width: 270px;
            height: 40px;
            margin-top:300px;
            margin-left:910px;
        }
        .contain .email input {
            width: 100%;
            height:100%;
            outline: none;
            padding-left:10px;
        }
        .contain .email span {
            position:absolute;
            top:6px;
            right:6px;
            width:80px;
            height:27px;
            line-height: 27px;
            text-align: center;
            display:block;
            background-color: #333;
            color:#fff;
        }
    /* 底部二维码部分 end*/
</style>
