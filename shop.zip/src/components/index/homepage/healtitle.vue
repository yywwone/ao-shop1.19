<template>
  <div>
      <span class="spanleft">|</span><span class="spanleft">健康食品</span>
      <div class="spanright">
          <span>健康食品</span><span>/</span>
          <span>营养保健</span><span>/</span>
          <span>美妆护肤</span><span>/</span>
          <span>生活护理</span>
          <span>更多护理</span>
      </div>
  </div>
</template>
<style scoped>
 .spanleft {
      display:inline-block;
      font-size: 28px;
      height: 55px;
      line-height: 55px;
  }
  .spanright {
      display: inline;
      float:right;
  }
</style>
<script>
export default {
  
}
</script>


