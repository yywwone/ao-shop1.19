<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  import index from './components/index/index'
export default {
  name: 'app',
  components: {
    
  }
}
</script>

<style>
</style>
