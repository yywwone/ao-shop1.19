// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import App from './App'
Vue.use(ElementUI)

// 引入公共css样式
import Css from './assets/css/reset.css'
import Router from './router'

Vue.config.productionTip = false

//路由分配
import VueRouter from 'vue-router'
//注册路由
Vue.use(VueRouter)
//创建路由对象
 var router=new VueRouter()
 Router(router)

new Vue({
  el: '#app',
  render: h => h(App),
  router
  })